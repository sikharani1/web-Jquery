/**
 * Created by sikharani on 4/5/17.
 */

// Function to get the Data from the RIT IST website API using proxy.php file uploaded by me,
// it will show the spinner image till website fully loads,if it is not able to get the data it will post error message at console.
function Xhr(t,d,id)
{
    return $.ajax(
        {type:t,
            url:'proxy.php',
            dataType:'json',
            data:d,
            cache:false,
            async:true,
            beforeSend:
                function(){$(id).append('<img src="images/spinner.gif" class="spin"/>');
                }})
        .always(function(){
            $(id).find('.spin').fadeOut(4000,function(){$(this).remove();
            });})
        .fail(function()
        {console.log("There was a problem while trying to get data at "+d);});
}
//To check whether the page Document Object Model (DOM) is ready for JavaScript code to execute
$(document).ready(function() {
//To load the menu plugin "sidr" which slides horizontally and utilises jquery version jQuery_2_2_0

    jQuery_2_2_0('#menu').sidr();
//To get data from the "ABOUT" API and add it to the #about division
    Xhr('get', {path: '/about/'}, '#about').done(function (json) {
        var x = '<div style= "width: 60%; height: auto;color:white; padding:5px;margin: 0 auto;text-align:center;" > <h2><span  style="color:white;font-weight: bold;color:#18d1f2;font-size:45px;text-align:center">INFORMATION </span><span  style="color:white;font-weight: bold;font-size:45px">SCIENCES AND</span></h2><br/><h2><span  style="color:white;font-weight: bold;font-size:45px">TECHNOLOGIES</span></h2>';
        x += '<p><h3>' + json.title + '</h3></p>';
        x += '<p style=" font-size: medium">' + json.description + '</p>';
        x += '<b style="color:#F36E21; letter-spacing: 1px">' + json.quote + '</b><br>';
        x += "~" + json.quoteAuthor + '</p></div>';
        $('#about').html(x);
    });



//To get data from the "DEGREES" API and undergraduate/graduate node and add it to the #UGdegrees/#Gdegrees division
    Xhr('get', {path: '/degrees/undergraduate/'}, '#UGdegrees').done(function (json) {
        var x='<div class="ziehharmonika">';
        x+='<b><p  style= "align-content: center;align-items: center; font-size: medium">' +"UNDER GRADUATE"+ '</p></b>';
        var y="";
        jQuery_1_11_1.each(json.undergraduate, function (i, course) {
            x += '<h3>' + course.title + '</h3>';
            x += '<div><p>' + course.description +'<br>';

            jQuery_1_11_1.each(course.concentrations, function(j,conc)
            {
                y +=conc+'<br>';
            });

            x+= y+'</p></div>';


        });
        x+='</div>';
        jQuery_1_11_1('#UGdegrees').append(x);


    });

    Xhr('get', {path: '/degrees/graduate/'}, '#Gdegrees').done(function (json) {
        var x='<div class="ziehharmonika">';
        x+='<b><p  style= "align-content: center;align-items: center;font-size: medium">' +"GRADUATE"+ '</p></b>';

        jQuery_1_11_1.each(json.graduate, function (i, course) {

            var y="";
            if (i<3) {

                x += '<h3>' + course.title + '</h3>';
                x += '<div><p>' + course.description + '<br>';

                jQuery_1_11_1.each(course.concentrations, function (j, conc) {
                    y += conc + '<br>';
                });
            }
            else {
                x += '<h3 style="text-transform: capitalize">' + course.degreeName + '</h3>';
                x += '<div><p>';
                jQuery_1_11_1.each(course.availableCertificates, function (j, cert) {
                    y += cert + '<br>';
                });
            }
            x+= y+'</p></div>';


        });
        x+='</div>';
        jQuery_1_11_1('#Gdegrees').append(x);
        /*To call the plugin "ziehharmonika" which utilises jquery version jQuery_1_11_1 and is a contrallable panel
        on the #Gdegrees and #UGdegrees div which are having the same type of div inside of class "ziehharmonika"*/
        jQuery_1_11_1('.ziehharmonika').ziehharmonika({
            collapsible: true,
            prefix: '★'
        });


        jQuery_1_11_1('.ziehharmonika h3:eq(0)').ziehharmonika('open');


    });
    //To get data from the "PEOPLE" API and add it to the #people division and show details of each member
    Xhr('get', {path: '/people/faculty/'}, '#people').done(function (json) {
        var x='<div class="wmg-container">';
        jQuery_1_11_1.each(json.faculty, function (i, fac) {

            x += '<div class="wmg-item">';

            x += '<div class="wmg-thumbnail">';

            x += '<div class="wmg-thumbnail-content">';




            x += '<img src= "'+fac.imagePath+'" alt="image">';

            x += '</div><div class="wmg-arrow"></div></div><div class="wmg-details" ><span style="right:75px" class="wmg-close"></span><div class="wmg-details-content" style=" width:80%; height:100% ;background:#ffd700;border: 5px solid black;padding: 2cm;">';
            // <!-- Image details -->

            x +='<div class="container exemplo"><div class="row"><div class="col-md-6"></div><div class="col-md-6">';
            x += '<h2>'+fac.name+'</h2>';

            x += '<hr>';

            x += '<p>' + fac.username + '<br>' + fac.tagline + '<br>' + fac.title + '<br>' + fac.interestArea + '<br>' + fac.office + '<br>' + fac.website + '<br>' + fac.phone + '<br>' + fac.email + '<br>';
            if(fac.twitter==null | fac.facebook==null)
            { x+='</p>'; }
            else
            {
                x+=fac.twitter+'<br>'+fac.facebook;
                x+='</p>';
            }

            x += '<a href="#research" class="btn btn-primary btn-lg" title="Read more">' + "Read more" + '</a></div>';
            x += '</div></div></div></div></div>';
        });



        x+='</div>';

        jQuery_1_11_1('#people').append(x);
        jQuery_1_11_1('.wmg-container').WMGridfolio();
    //To call plugin "WMGridFolio" on the "people" division which shows each members details in a popup dialog box
    });

//To get data from the "EMPLOYMENT" API and "coopTable" node and add it to the #coop division
    Xhr('get', {path: '/employment/coopTable/coopInformation/'}, '#coop').done(function (json) {
        console.log(json);
        var x;
        jQuery_2_2_2.each(json.coopInformation, function (i, coop) {
            x += '<tr><td>' + coop.employer + '</td>';
            x += '<td>' + coop.degree + '</td>';
            x += '<td>' + coop.city + '</td>';
            x += '<td>' + coop.term + '</td></tr>';


        });
        jQuery_2_2_2('#cooptbody').append(x);
        jQuery_2_2_2('#cooptable').DataTable(); // To call the plugin "datatable" on the 'coop" table
    });
//To get the data from "RESEARCH" API about the research being done in each field
    Xhr('get', {path: '/research/byInterestArea'}, '#research').done(function (json) {
        console.log(json);
        var x="";

        $.each(json.byInterestArea, function (i,res) {

            x='<div style=" width:80%; height:100% ;background:#ffd700;border: 5px solid black;text-align: justify;padding: 2cm;margin:2px" id="id'+i+'" class="small-dialog zoom-anim-dialog mfp-hide"><p>';

            var y="";
            $.each(res.citations, function (j,cit) {
                y += '<b>'+(j+1)+".</b>    "+cit + '<br><br>';
            });
            x+=y+'</p></div>';
            x+='<div class="linkdiv"><a class="popup-with-move-anim reslink " href="#id'+i+'">'+ res.areaName+'</a></div>';
            $('#research').append(x);


        });

//To call the lightbox plugin "magnificpopup" on the "linkdiv" division having links with class as "popup-with-move-anim" for animation

        $('.popup-with-move-anim').magnificPopup({
            type: 'inline',


            fixedContentPos: false,
            fixedBgPos: true,

            overflowY: 'auto',

            closeBtnInside: true,
            preloader: false,

            midClick: true,
            removalDelay: 300,
            mainClass: 'my-mfp-slide-bottom'


        });





    });
//To call the lightbox plugin "magnificpopup" on the "videobar" division having links with class as "popup-youtube" for animation
    $('.popup-youtube').magnificPopup({
        disableOn: 700,
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,

        fixedContentPos: false
    });
//To get the data from  "MINORS" API to display each minor and its courses offered details
    Xhr('get',{path:'/minors/'},'#minors').done(function(json) {

        var x = '';

        var div = '';
        $.each(json.UgMinors, function (i, minor) {
            var icon = '';
            if (minor.name == 'MEDINFO-MN') {
                icon = '<i class="fa fa-medkit fa-2x"></i>';
            }
            if (minor.name == 'DBDDI-MN') {
                icon = '<i class="fa fa-database fa-2x"></i>';
            }
            if (minor.name == 'MDDEV-MN') {
                icon = '<i class="fa fa-code fa-2x"></i>';
            }
            if (minor.name == 'GIS-MN') {
                icon = '<i class="fa fa-map-marker fa-2x"></i>';
            }

            if (minor.name == 'MDEV-MN') {
                icon = '<i class="fa fa-mobile fa-2x"></i>';
            }
            if (minor.name == 'WEBD-MN') {
                icon = '<i class="fa fa-html5 fa-2x"></i>';
            }
            if (minor.name == 'WEBDD-MN') {
                icon = '<i class="fa fa-object-group fa-2x"></i>';
            }
            if (minor.name == 'NETSYS-MN') {
                icon = '<i class="fa fa-sitemap fa-2x"></i>';
            }
            $('#minors').append('<div style="display: block; align-content: center" class="minor" id=' + minor.name + '>' + icon + '<span style="margin-right:10px"></span><b>' + minor.title + '</b></div><div class="desc" ><p style="text-align:justify;">' + minor.description + '</p></div>');
            x = '<p><span style="margin-left: 15px ;font-weight:bold">Courses :</span>';
            x += '<span style="margin-right: 50px"><div style="display:block" id="courses'+minor.name+'"></div></span>';


//To get the detailed data about each course
            $.each(minor.courses, function (i, course) {

                var div = '';
                Xhr('get', {path: '/course/courseID=' + course}, '#courses'+minor.name+'').done(function (courseinformation) {

                    div += '<div style=" width:80%; height:100% ;background:#ffd700;border: 5px solid black;text-align: justify;padding: 2cm;" class="small-dialog zoom-anim-dialog mfp-hide" id="coursecontent' + course + '">';
                    div+='<h1 style="font-weight: bold">' + courseinformation.title + '</h1><hr><p>' + courseinformation.description + '</p></div>';

                    div+='<div style="display: inline; padding-right: 15px; padding-left: 15px"><a   class="popup-with-move-anim" href="#coursecontent' + course + '">'+course+'</a></div>';
                    $("#courses"+minor.name).append(div);
//To call the lightbox plugin "magnificpopup" on each course division having links with class as "popup-with-move-anim" for animation

                    $('.popup-with-move-anim').magnificPopup({
                        type: 'inline',


                        fixedContentPos: false,
                        fixedBgPos: true,

                        overflowY: 'auto',

                        closeBtnInside: true,
                        preloader: false,

                        midClick: true,
                        removalDelay: 300,
                        mainClass: 'my-mfp-slide-bottom'


                    });
                });


            });
            $('#minors').append(x);
            $('#minors').append('</p><hr style="color:#F36E21;"><br>');



        });
    });
//To get the data from  "EMPLOYMENT" API to display employment and coop details and our consistent employer's information
    Xhr('get',{path:'/employment/'},'#employment').done(function(json) {
        console.log(json);


        var x='<div id="intro"><h1 style="font-weight: bold;text-align:center;color:red;font-family:Papyrus">'+json.introduction.title+'</h1>';
        x += '<div style="overflow: hidden; padding-bottom: 20px ;float:center">';
        $.each(json.introduction.content, function (i,emp) {
            x += '<div style="display:inline; width: 40%; float:left; margin:5%"><h3 style="font-weight: bold;text-align:center;font-size:18px">'+emp.title+'</h3>';
            x += '<hr><p style="font-size:14px ;text-align:justify; margin:5px 20px 2px 20px;">'+emp.description+'</p></div>';

        });
        x+='</div>';

//To get the recent degreestatistics details from the "degreestatistics" node of the "employment" api
        $.each(json.degreeStatistics.statistics, function (i,stat) {
            x += '<div style="float:left;height:150px;width:24%;margin:5px;background-color:#18d1f2;margin-bottom:50px">';
            x += '<div style="position: relative;transform: translateY(-50%);margin:60px 20px 2px 20px;">';
            x += '<span style="color:#ffffff;font-size:x-large;">' + stat.value + '</span>';
            x += '<p style="color: #f8f8ff; font-size: medium">' + stat.description + '</p>';
            x += '</div>';
            x += '</div>';
        });
        x+='</div>';
        $('#employment').append(x);

    });
    Xhr('get',{path:'/employment/'},'#employers').done(function(json) {
        var x = '<div class="employers"><br/>';
        x += '<h3 style="font-weight: bold;text-align:center;font-size:18px; text-transform:uppercase">' + json.employers.title + '</h3><br><marquee style="color:red">';
        $.each(json.employers.employerNames, function (i, item) {
            x += item+'&nbsp'+"|"+'&nbsp';
        });
        x += '</marquee></div>';
        $('#employers').append(x);

    });

    Xhr('get',{path:'/footer/'},'#social').done(function(json) {
        console.log(json);
        var x='';
        x += '<div style="width: 100%;float:left;background-color:#F36E21; border-style:solid;border-color:darkblue;border-width: 1px"><p style="color: white;text-align: center; font-size: 15px">'+ json.social.title + '</p>';
        x += '<blockquote style="color: white; text-align: center">' + json.social.tweet + '</blockquote><p style="color: white;text-align: center">' + json.social.by + '</p>';
        x += '<p><a href="' + json.social.twitter + '"><span style="margin-left: 20px"><i class="fa fa-twitter fa-2x" style="color:white"></i><span style="margin-left: 20px"></span></a>';
        x += '<a href="' + json.social.facebook + '"><i class="fa fa-facebook fa-2x" style="color:white"></i><span style="margin-left: 20px"></span></a></p></div>';
        $('#social').append(x);
    });
//To get the data from  "FOOTER" API to display the quicklinks,social and the copyright details
    Xhr('get',{path:'/footer/'},'#footer').done(function(json)
    {
        var x='';
        x+='<div style="padding-top: 30px">';
        x+='<div style="width: 20%;height: 100%;float:left">';
        x+='<ul>';
        $.each(json.quickLinks,function(i,quick)
        {
            x+='<li style="list-style: none; margin-bottom: 20px;"><a style="text-decoration: none;color: white; font-size: 15px" href="'+quick.href+'">'+quick.title+'</a></li>';
        });
        x+='</ul></div>';
        x+='<div id="copyright" style="width:60%;float: left;text-align: center;padding-top: 130px; color: white; height:100%; font-size: 15px"></div>';
        var y=json.copyright.html;
        var z='<div style="padding-top: 60px">'+y+'</div>';

        $('#footer').append(x);
        $('#copyright').html(z);
    });
    var logo='';
    logo+='<div id="logo"><img src="images/Rochester Institute of Technology (RIT)_200px.png" style="float: right;width: 15%; height: 80%; margin-right:5%; margin-top:5%"></img></div>';
    $('#footer').append(logo);
});
